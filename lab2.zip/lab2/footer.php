<?php function footer_site(){?>

	<style>
#footer{
	width: 100%;
	height: 105px;
	background: #FFA945;
	display: block;
}
.text{
	font-size: 18px;
	color: white;
	display: flex;
    font-size: 18px;
    color: white;
    align-items: center;
    justify-content: space-between;
}
	</style>

	<footer id = "footer">
		<div class="container">
			<div class ="text">
				<p class="mail">Разработчики:<br>
					sofya-fedorova-2014@mail.ru<br>
					albert.e.m@mail.ru
				</p>
				<p class="mail">
					Объявления.ru — сайт объявлений
				</p>
			</div>
		</div>
	</footer>
<?php }?>